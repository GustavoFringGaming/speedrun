CrippleCraft upside down pack

How to install
--------------
- Install fabric 1.20.1
- Copy the mods folder

How to play
-----------
Once in game, UNBIND space and sprint. Then you're done!